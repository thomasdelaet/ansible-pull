#!/bin/sh

touch /root/test